<?php
header('Access-Control-Allow-Origin: *');
include '../config.php';

try {
    $db = new PDO("mysql:host=localhost;dbname={$database};charset=utf8",
        $username, $password);

    $sql = 'SELECT * FROM message WHERE receiver = :client ORDER BY id LIMIT 1';
    $ps = $db->prepare($sql);
    $ps->bindValue(':client', $_GET['client']);
    $ps->execute();

    if ($message = $ps->fetch(PDO::FETCH_ASSOC)) {
        $sql = 'DELETE FROM message WHERE id = :id';
        $ps = $db->prepare($sql);
        $ps->bindValue(':id', $message['id']);
        $ps->execute();

        echo json_encode($message);
    } else {
        echo "null";
    }
    
} catch (Exception $e) {
    echo "null";
}