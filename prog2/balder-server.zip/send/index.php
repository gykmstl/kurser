<?php
header('Access-Control-Allow-Origin: *');
include '../config.php';

try {
    $db = new PDO("mysql:host=localhost;dbname={$database};charset=utf8",
        $username, $password);

    $sql = 'INSERT INTO message VALUES(NULL, :content, :sender, :receiver)';
    $ps = $db->prepare($sql);
    $ps->bindValue(':content', $_GET['content']);
    $ps->bindValue(':sender', $_GET['sender']);
    $ps->bindValue(':receiver', $_GET['receiver']);
    $ok = $ps->execute();

    echo $ok ? 1 : 0;
} catch (Exception $e) {
    echo 0;
}