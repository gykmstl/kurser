<?php
header('Access-Control-Allow-Origin: *');

// Ändra här:
$database = 'username_database';
$username = 'username';
$password = 'password';