<?php
header('Access-Control-Allow-Origin: *');
include '../config.php';

try {
    $db = new PDO("mysql:host=localhost;dbname={$database};charset=utf8",
        $username, $password);

    $sql = 'INSERT INTO client VALUES (:client)';
    $ps = $db->prepare($sql);
    $ps->bindValue(':client', $_GET['client']);
    $ok = $ps->execute();

    echo $ok ? 1 : 0;
} catch (Exception $e) {
    echo 0;
}