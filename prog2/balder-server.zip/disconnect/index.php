<?php
header('Access-Control-Allow-Origin: *');
include '../config.php';

try {
    $db = new PDO("mysql:host=localhost;dbname={$database};charset=utf8",
        $username, $password);

    $sql = 'DELETE FROM message WHERE sender = :client OR receiver = :client';
    $ps = $db->prepare($sql);
    $ps->bindValue(':client', $_GET['client']);
    $ok1 = $ps->execute();

    $sql = 'DELETE FROM client WHERE client = :client';
    $ps = $db->prepare($sql);
    $ps->bindValue(':client', $_GET['client']);
    $ok2 = $ps->execute();

    echo $ok1 && $ok2 ? 1 : 0;
} catch (Exception $e) {
    echo 0;
}