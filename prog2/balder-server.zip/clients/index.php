<?php

header('Access-Control-Allow-Origin: *');
include '../config.php';

try {
    $db = new PDO("mysql:host=localhost;dbname={$database};charset=utf8",
        $username, $password);

    $sql = 'SELECT * FROM client';
    $ps = $db->prepare($sql);
    $ps->execute();
    $clients = $ps->fetchAll(PDO::FETCH_COLUMN, 0);

    echo json_encode($clients);
} catch (Exception $e) {
    echo "null";
}