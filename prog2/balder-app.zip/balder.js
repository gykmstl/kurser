// BalderJS
// version 1.0 (2021-08-25) 
// Mattias Steinwall
// Baldergymnasiet, Skellefteå, Sweden
//
// Initialize
//
let _parent;
let _input;
let _output;
let _canvas;
export let W;
export let H;
export let ctx;
let _action = () => { clearOutput(); };
const _lbltags = ["input", "meter", "output", "progress", "select", "textarea"];
let _bgcolor = getComputedStyle(document.body).getPropertyValue("background-color");
let _color = getComputedStyle(document.body).getPropertyValue("color");
class BalderParent extends HTMLElement {
    constructor() {
        super();
        const shadow = this.attachShadow({ mode: 'open' });
        _parent = document.createElement("div");
        shadow.appendChild(_parent);
    }
}
class BalderInput extends HTMLElement {
    constructor() {
        super();
        const shadow = this.attachShadow({ mode: 'open' });
        const label = document.createElement("label");
        label.style.display = "block";
        const span = add("span", label);
        span.style.fontFamily = "monospace";
        add("br", label);
        _input = add("textarea", label);
        _input.placeholder = "input";
        _input.rows = 5;
        _input.style.display = "block";
        _input.style.boxSizing = "border-box";
        _input.style.width = "100%";
        _input.style.resize = "none";
        _input.style.backgroundColor = "inherit";
        _input.style.color = "inherit";
        _input.addEventListener("keyup", _setPrompt);
        _input.addEventListener("click", () => {
            _setPrompt();
            setTimeout(() => {
                _setPrompt();
            }, 5);
        });
        _input.addEventListener("keydown", event => {
            if (!_submitOnInput && event.code == "Enter" && !event.shiftKey) {
                event.preventDefault();
                if (_output)
                    _output.value = "";
                _inputLineIndex = 0;
                _submit();
                _input.select();
            }
        });
        _input.addEventListener("input", () => {
            _inputLines = _input.value.split("\n");
            _errorElt?.remove(); // ?
            if (_submitOnInput) {
                if (_output)
                    _output.value = "";
                _inputLineIndex = 0;
                _submit();
            }
        });
        shadow.appendChild(label);
    }
}
class BalderOutput extends HTMLElement {
    constructor() {
        super();
        const shadow = this.attachShadow({ mode: 'open' });
        _output = document.createElement("textarea");
        _output.placeholder = "output";
        _output.rows = 5;
        _output.style.display = "block";
        _output.style.boxSizing = "border-box";
        _output.style.width = "100%";
        _output.style.resize = "none";
        _output.style.backgroundColor = "inherit";
        _output.style.color = "inherit";
        _output.readOnly = true;
        _output.addEventListener("keydown", event => {
            if (event.code == "Enter" && !event.shiftKey) {
                event.preventDefault();
                _action();
            }
        });
        shadow.appendChild(_output);
    }
}
let _scaleX = 1;
let _scaleY = 1;
let _codes = new Set();
class BalderCanvas extends HTMLElement {
    constructor() {
        super();
        const shadow = this.attachShadow({ mode: 'open' });
        _canvas = document.createElement("canvas");
        _canvas.addEventListener("keydown", event => {
            event.preventDefault();
            _key = event.key;
            if (keyboard[event.code] !== false) {
                keyboard[event.code] = true;
                _codes.add(event.code);
            }
        });
        _canvas.addEventListener("keyup", event => {
            _key = null;
            keyboard[event.code] = null;
            _codes.delete(event.code);
        });
        _canvas.addEventListener("mousedown", event => {
            event.preventDefault();
            _canvas.focus();
            if (mouse[event.button] !== false) {
                mouse[event.button] = true;
            }
        });
        _canvas.addEventListener("mouseup", event => {
            mouse[event.button] = null;
        });
        _canvas.addEventListener("mousemove", event => {
            const rect = _canvas.getBoundingClientRect();
            mouse.x = (event.clientX - rect.left) * _scaleX;
            mouse.y = (event.clientY - rect.top) * _scaleY;
            mouse.over = true;
        });
        _canvas.addEventListener("mouseout", () => {
            mouse.over = false;
            mouse[0] = mouse[1] = mouse[2] = null;
        });
        _canvas.addEventListener("contextmenu", event => {
            event.preventDefault();
        });
        function touchHandler(event) {
            event.preventDefault();
            _canvas.focus();
            const rect = _canvas.getBoundingClientRect();
            touchscreen.touches = [];
            if (_touched !== false) {
                _touched = null;
                for (let i = 0; i < event.touches.length; i++) {
                    touchscreen.touches[i] = {
                        x: event.touches[i].clientX - rect.left,
                        y: event.touches[i].clientY - rect.top,
                        id: event.touches[i].identifier
                    };
                    if (i === 0) {
                        _touched = true;
                        touchscreen.x = touchscreen.touches[0].x;
                        touchscreen.y = touchscreen.touches[0].y;
                    }
                }
                return;
            }
            if (event.touches.length === 0) {
                _touched = null;
            }
        }
        _canvas.addEventListener("touchstart", touchHandler);
        _canvas.addEventListener("touchend", touchHandler);
        _canvas.addEventListener("touchmove", touchHandler);
        _canvas.addEventListener("blur", () => {
            for (const code of _codes) {
                keyboard[code] = null;
            }
            _key = null;
            _codes.clear();
            _touched = null;
        });
        _canvas.style.width = "100%";
        _canvas.style.height = "100%";
        ctx = _canvas.getContext("2d");
        ctx.strokeStyle = _color;
        ctx.fillStyle = _color;
        _canvas.tabIndex = 0;
        shadow.appendChild(_canvas);
    }
    connectedCallback() {
        this.style.flex = "1";
        this.style.display = "flex";
        resetCanvas();
    }
}
customElements.define('balder-parent', BalderParent);
customElements.define('balder-input', BalderInput);
customElements.define('balder-output', BalderOutput);
customElements.define('balder-canvas', BalderCanvas);
let _initUpdateables = [];
let _update = () => { };
export function setUpdate(handler = () => { }) {
    _update = handler;
    _canvas.focus();
}
function _updateHandler() {
    for (let iu of _initUpdateables) {
        iu.initUpdate();
    }
    _update();
    requestAnimationFrame(_updateHandler);
}
_updateHandler();
let _submit = () => { };
let _submitOnInput = true;
export function setSubmit(handler = () => { }, onInput = true) {
    if (!_input)
        add("balder-input");
    _submit = handler;
    _submitOnInput = onInput;
}
let _key;
let _inputLines = [];
let _inputLineIndex = 0;
export function setTheme(value) {
    document.body.style.setProperty("color", _color = (value == "dark" ? "white" : "black"));
    document.body.style.setProperty("background-color", _bgcolor = (value == "dark" ? "black" : "white"));
}
let _URLParams = true;
export function disableURLParams() {
    _URLParams = false;
}
let _errNr = 0;
let _errorElt;
window.onerror = (message) => {
    if (!_errorElt) {
        _errorElt = add("output", document.body);
    }
    _errorElt.value = `(#${++_errNr}) ${String(message)}`;
    _errorElt.style.color = "white";
    _errorElt.style.backgroundColor = "red";
    _errorElt.style.position = "fixed";
    _errorElt.style.bottom = "0";
    _errorElt.style.left = "0";
    _errorElt.style.width = "100%";
    _errorElt.style.zIndex = "2147483647";
    _errorElt.focus();
    _errorElt.onclick = () => _errorElt.remove();
};
window.addEventListener("unhandledrejection", event => {
    throw event.reason;
});
function resetCanvas() {
    _scaleX = 1;
    _scaleY = 1;
    let W0 = parseInt(getComputedStyle(_canvas).width);
    let H0 = parseInt(getComputedStyle(_canvas).height);
    _canvas.width = 0;
    _canvas.height = 0;
    if (parseInt(getComputedStyle(_canvas).width) > 1) {
        W = parseInt(getComputedStyle(_canvas).width);
    }
    else {
        W = W0;
    }
    if (parseInt(getComputedStyle(_canvas).height) > 1) {
        H = parseInt(getComputedStyle(_canvas).height);
    }
    else {
        H = H0;
    }
    _canvas.width = W;
    _canvas.height = H;
}
window.addEventListener("resize", () => {
    if (_canvas) {
        _scaleX = W / _canvas.getBoundingClientRect().width;
        _scaleY = H / _canvas.getBoundingClientRect().height;
    }
});
let _promptLines;
let _promptLineindex = 0;
let _promptNumbering;
function _setPrompt() {
    if (_promptLines == null)
        return;
    const toCursor = _input.value.substr(0, _input.selectionStart);
    _promptLineindex = toCursor.split("\n").length - 1;
    setLabel(_input, _promptLines[_promptLineindex]);
    let n = 0;
    let indexStart = _promptLines.length;
    while (indexStart > 0 && /[\0]/.test(_promptLines[indexStart - 1])) {
        n++;
        indexStart--;
    }
    if (_promptLineindex >= indexStart && n > 0) {
        const pr = String(_promptNumbering(Math.floor((_promptLineindex - indexStart) / n), _inputLines));
        const index = indexStart + ((_promptLineindex - indexStart) % n);
        const prompt = _promptLines[index].replace(/\0/g, pr);
        setLabel(_input, prompt);
    }
}
export function setPrompts(...lines) {
    if (!_input)
        add("balder-input");
    _promptLines = lines;
    _setPrompt();
}
export function setPromptNumbering(value) {
    _promptNumbering = value;
}
setPromptNumbering(n => n + 1);
export function setInputRows(value) {
    if (!_input)
        add("balder-input");
    _input.rows = value;
    resetCanvas();
}
export function setInput(value = "") {
    if (!_input)
        add("balder-input");
    _input.value = value;
    _inputLineIndex = 0;
    _input.dispatchEvent(new Event("input"));
    _input.scrollTop = _input.scrollHeight;
}
export function input() {
    if (!_input)
        add("balder-input");
    return _inputLines[_inputLineIndex++] ?? "";
}
export function setOutputRows(value) {
    if (!_output)
        add("balder-output");
    _output.rows = value;
    resetCanvas();
}
export function clearOutput() {
    if (!_output)
        add("balder-output");
    _output.value = "";
}
export function output(value, end = "\n") {
    if (!_output)
        add("balder-output");
    if (arguments.length > 0) {
        _output.value += str(value);
    }
    _output.value += end;
    _output.scrollTop = _output.scrollHeight;
}
export function str(value) {
    if (typeof value === "object" && value != null && (value.toString === Object.prototype.toString || value.toString === Array.prototype.toString)) {
        if (typeof value[Symbol.iterator] === "function") {
            value = Array.from(value);
        }
        try {
            return JSON.stringify(value);
        }
        catch { }
    }
    return String(value);
}
//
// Load
//
window.addEventListener("load", () => {
    if (_input) {
        _input.focus();
        _input.dispatchEvent(new Event("input"));
    }
    if (_URLParams) {
        const params = new URL(location.href).searchParams;
        const fParam = params.get("f"); // file
        const mParam = params.get("m"); // mode
        const sParam = params.get("s"); // script
        const pParam = params.get("p"); // prompt
        const iParam = params.get("i"); // input
        const oParam = params.get("o"); // output
        const irParam = params.get("ir"); // input-rows
        const orParam = params.get("or"); // output-rows
        if (irParam) {
            setInputRows(+irParam);
        }
        if (orParam) {
            setOutputRows(+orParam);
        }
        let _savedValue;
        function testOutput(testValue = _savedValue) {
            if (_input)
                _input.readOnly = true;
            if (testValue == null)
                return; // todo
            _savedValue = testValue = testValue.trimEnd();
            let outputValue = _output.value
                .split("\n")
                .map(line => line.trimEnd())
                .join("\n")
                .trimEnd();
            _output.value = outputValue;
            if (outputValue === testValue) {
                _output.style.backgroundColor = "palegreen";
                _output.style.color = "black";
                _action = () => {
                    params.delete("i");
                    params.delete("o");
                    location.assign(location.origin + "?" + params);
                };
            }
            else {
                let offset = 0;
                while (outputValue[offset] == testValue[offset]) {
                    offset++;
                }
                _output.style.backgroundColor = "lightSalmon";
                _output.focus();
                _output.setSelectionRange(offset, outputValue.length);
                _action = () => {
                    if (_output.value === outputValue) {
                        _output.style.backgroundColor = "palegreen";
                        _output.value = testValue;
                        _output.focus();
                        _output.setSelectionRange(offset, testValue.length);
                    }
                    else {
                        _output.style.backgroundColor = "lightSalmon";
                        _output.value = outputValue;
                        _output.focus();
                        _output.setSelectionRange(offset, outputValue.length);
                    }
                };
            }
        }
        if (mParam == "cs") { // create-script
            if (!_input)
                add("balder-input");
            if (!_output)
                add("balder-output");
            try {
                setPrompts("script (line \0)");
            }
            catch { }
            if (sParam) {
                _input.value = decodeURIComponent(sParam);
            }
            _submit = () => {
                _output.value = "";
                output(encodeURIComponent(_input.value));
            };
            _action = () => {
                params.set("s", _output.value.trimEnd());
                params.delete("m");
                location.assign(location.origin + "?" + params);
            };
            _input.focus();
            return;
        }
        let fi;
        let fo;
        if (fParam == "i" || fParam == "io") {
            fi = add("input:file", { label: "input:", placement: "left" });
            if (!_input)
                add("balder-input");
            fi.oninput = () => {
                let fr = new FileReader();
                fr.readAsText(fi.files[0]);
                if (mParam == "c") {
                    fr.onload = () => {
                        setInput(fr.result);
                    };
                }
                else {
                    fr.onload = () => {
                        setInput(fr.result);
                        fi.focus();
                    };
                }
            };
        }
        if (fParam == "o" || fParam == "io") {
            fo = add("input:file", { label: "output:", placement: "left" });
            if (!_output)
                add("balder-output");
            fo.oninput = () => {
                let fr = new FileReader();
                fr.readAsText(fo.files[0]);
                if (mParam == "c") {
                    fr.onload = () => {
                        clearOutput();
                        output(fr.result);
                    };
                }
                else {
                    fr.onload = () => {
                        testOutput(fr.result);
                        if (fi)
                            fi.disabled = true;
                        fo.disabled = true;
                    };
                }
            };
        }
        if (mParam == "c") { // create
            if (!_input)
                add("balder-input");
            if (!_output)
                add("balder-output");
            let prompt = _input.parentElement.querySelector("span");
            prompt.contentEditable = "true";
            prompt.addEventListener("click", event => {
                event.preventDefault();
            });
            prompt.addEventListener("keydown", event => {
                if (event.code == "Enter") {
                    event.preventDefault();
                    _input.focus();
                }
            });
            prompt.addEventListener("focus", () => {
                prompt.textContent = _promptLines?.[_promptLineindex]?.replace(/\0/g, '\\0');
            });
            prompt.addEventListener("blur", () => {
                let p = prompt.textContent.replace(/\\0/g, '\0').trimEnd();
                if (!_promptLines)
                    _promptLines = [];
                _promptLines[_promptLineindex] = p;
                while (_promptLines.length > 0 && !_promptLines[_promptLines.length - 1]) {
                    _promptLines.length--;
                }
            });
            _output.readOnly = false;
            _action = () => {
                const pp = _promptLines?.join("\n").trimEnd();
                const ip = _input?.value.trimEnd();
                const op = _output?.value.trimEnd();
                params.delete("f");
                params.delete("m");
                params.delete("p");
                params.delete("i");
                params.delete("o");
                if (pp)
                    params.set("p", pp);
                if (ip)
                    params.set("i", ip);
                if (op)
                    params.set("o", op);
                location.assign(location.origin + "?" + params);
            };
        }
        if (sParam) {
            eval(decodeURIComponent(sParam));
        }
        if (pParam !== null) {
            if (!_input)
                add("balder-input");
            _promptLines = decodeURIComponent(pParam).split("\n");
            _setPrompt();
        }
        if (iParam !== null) {
            if (!_input)
                add("balder-input");
            _input.value = decodeURIComponent(iParam);
            _input.dispatchEvent(new Event("input"));
            _input.scrollTop = _input.scrollHeight;
        }
        if (oParam !== null) {
            if (!_output)
                add("balder-output");
            if (mParam == "c") {
                _output.value = decodeURIComponent(oParam); // todo, scroll?
            }
            else {
                testOutput(decodeURIComponent(oParam));
                if (fi)
                    fi.disabled = true;
                if (fo)
                    fo.disabled = true;
            }
        }
    }
});
let _server;
let _client;
let _messages = [];
let _receiveID;
export async function connect(client, server = _server) {
    client = client.trim();
    if (client.length == 0)
        throw new Error("'client' can not be connected");
    if (server) {
        try {
            let response = await fetch(server + "connect/?client=" + client);
            if (await response.text() == "1") {
                _server = server;
                _client = client;
                _receive();
                window.onbeforeunload = () => true; // todo, check
            }
            else {
                throw new Error("'client' can not be connected");
            }
        }
        catch (error) {
            throw new Error("Server error");
        }
    }
    else {
        let clients = JSON.parse(localStorage.getItem("clients"));
        if (clients) {
            if (clients.includes(client)) {
                throw new Error("'client' can not be connected");
            }
            clients.push(client);
        }
        else {
            clients = [client];
        }
        _client = client;
        localStorage.setItem("clients", JSON.stringify(clients));
        if (!JSON.parse(localStorage.getItem("messages"))) {
            localStorage.setItem("messages", "[]");
        }
        _receive();
    }
}
export async function disconnect() {
    if (!_client)
        throw new Error("No server is connected");
    if (_server) {
        try {
            await fetch(_server + "disconnect/?client=" + _client, { keepalive: true });
        }
        catch (error) {
            throw new Error("Server error");
        }
    }
    else {
        let messages = JSON.parse(localStorage.getItem("messages"));
        messages = messages.filter(m => m.sender != _client && m.receiver != _client);
        localStorage.setItem("messages", JSON.stringify(messages));
        let clients = JSON.parse(localStorage.getItem("clients")).filter(c => c != _client);
        localStorage.setItem("clients", JSON.stringify(clients));
    }
    _client = null;
}
export async function send(content, receiver) {
    if (!_client)
        throw new Error("No server is connected");
    if (_server) {
        try {
            let response = await fetch(_server + 'send/?content=' + content + '&sender=' + _client + '&=receiver' + JSON.stringify(receiver));
            if (await response.text() != "1") {
                throw new Error("Server error");
            }
        }
        catch (error) {
            throw new Error("Server error");
        }
    }
    else {
        let messages = JSON.parse(localStorage.getItem("messages"));
        messages.push({ content: content, sender: _client, receiver: receiver });
        localStorage.setItem("messages", JSON.stringify(messages));
    }
}
export async function fetchClients(server = _server) {
    if (server) {
        try {
            let response = await fetch(server + 'clients/');
            return await response.json();
        }
        catch (error) {
            throw new Error("Server error");
        }
    }
    else {
        return JSON.parse(localStorage.getItem("clients"));
    }
}
async function _receive() {
    if (_server) {
        while (_client) {
            try {
                let response = await fetch(_server + 'receive/?client=' + _client);
                let message = await response.json();
                _messages.push(message);
            }
            catch (error) {
                throw new Error("Server error");
            }
        }
    }
    else {
        clearInterval(_receiveID);
        _receiveID = setInterval(() => {
            let messages = JSON.parse(localStorage.getItem("messages"));
            if (messages) {
                for (let i = 0; i < messages.length; i++) {
                    if (messages[i].receiver == _client) {
                        _messages.push(messages[i]);
                        messages.splice(i, 1);
                        localStorage.setItem("messages", JSON.stringify(messages));
                        break;
                    }
                }
            }
        }, 10); // todo, timeout?
    }
}
export async function receive() {
    if (!_client)
        throw new Error("No server is connected");
    while (true) {
        let message = poll();
        if (message) {
            return message;
        }
        await sleep(10); // todo, timeout?
    }
}
export function poll() {
    if (!_client)
        throw new Error("No server is connected");
    return _messages.shift();
}
window.addEventListener("unload", () => disconnect());
export function line(x1, y1, x2, y2, style = _color, lineWidth = 1) {
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.strokeStyle = style;
    ctx.lineWidth = lineWidth;
    ctx.stroke();
}
export function circle(x, y, radius, style = _color, lineWidth) {
    ctx.beginPath();
    ctx.ellipse(x, y, radius, radius, 0, 0, 2 * Math.PI);
    if (lineWidth) {
        ctx.lineWidth = lineWidth;
        ctx.strokeStyle = style;
        ctx.stroke();
    }
    else {
        ctx.fillStyle = style;
        ctx.fill();
    }
}
export function rectangle(x, y, width, height, style = _color, lineWidth) {
    if (lineWidth) {
        ctx.lineWidth = lineWidth;
        ctx.strokeStyle = style;
        ctx.strokeRect(x, y, width, height);
    }
    else {
        ctx.fillStyle = style;
        ctx.fillRect(x, y, width, height);
    }
}
export function triangle(x1, y1, x2, y2, x3, y3, style = _color, lineWidth) {
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(x3, y3);
    ctx.closePath();
    if (lineWidth) {
        ctx.lineWidth = lineWidth;
        ctx.strokeStyle = style;
        ctx.stroke();
    }
    else {
        ctx.fillStyle = style;
        ctx.fill();
    }
}
export function text(value, x = 0, y = 24, font = 24, style = _color, lineWidth) {
    if (typeof font == "number") {
        ctx.font = font + "px monospace";
    }
    else {
        ctx.font = font;
    }
    if (lineWidth) {
        ctx.lineWidth = lineWidth;
        ctx.strokeStyle = style;
        ctx.strokeText(value, x, y);
    }
    else {
        ctx.fillStyle = style;
        ctx.fillText(value, x, y);
    }
}
let _images = [];
export async function preloadImages(...paths) {
    await new Promise((resolve, reject) => {
        let loaded = array(paths.length, false);
        for (let i = 0; i < paths.length; i++) {
            const path = paths[i];
            if (_images[path] === undefined) {
                _images[path] = new Image();
                _images[path].src = path;
            }
            _images[path].addEventListener("load", () => {
                loaded[i] = true;
                if (loaded.every(item => item == true)) {
                    resolve();
                }
            });
            _images[path].addEventListener("error", () => {
                reject(new Error("One of 'paths' can not be loaded"));
            });
        }
    });
}
export async function image(path, x = 0, y = 0, width, height = width) {
    await new Promise((resolve, reject) => {
        const draw = () => {
            if (width) {
                ctx.drawImage(_images[path], x, y, width, height);
            }
            else {
                ctx.drawImage(_images[path], x, y);
            }
            resolve();
        };
        if (_images[path] === undefined) {
            _images[path] = new Image();
            _images[path].src = path;
            _images[path].addEventListener("load", draw);
            _images[path].addEventListener("error", () => {
                reject(new Error("'path' can not be loaded"));
            });
        }
        else if (_images[path].complete) {
            draw();
        }
        else {
            _images[path].addEventListener("load", draw);
        }
    });
}
export function clear(x = 0, y = 0, width = W, height = H) {
    ctx.clearRect(x, y, width, height);
}
export function fill(style = _bgcolor, x = 0, y = 0, width = W, height = H) {
    ctx.fillStyle = style;
    ctx.fillRect(x, y, width, height);
}
//
// Hitbox
//
export class Hitbox {
    x;
    y;
    width;
    height;
    constructor(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    intersects(other) {
        return (this.x + this.width > other.x &&
            this.x < other.x + other.width &&
            this.y + this.height > other.y &&
            this.y < other.y + other.height);
    }
    contains(x, y) {
        return (this.x + this.width > x &&
            this.x <= x &&
            this.y + this.height > y &&
            this.y <= y);
    }
    drawOutline(color = _color) {
        rectangle(this.x, this.y, this.width, this.height, color, 1);
    }
}
//
// Sprite
//
export class Sprite extends Hitbox {
    path;
    rows;
    columns;
    tag = {};
    _frames;
    index = 0;
    counter = 0;
    updatesPerFrame = 10;
    loop = true;
    constructor(path, rows = 1, columns = 1) {
        super(0, 0);
        this.path = path;
        this.rows = rows;
        this.columns = columns;
        this.setFrames(...range(rows * columns));
    }
    setFrames(...value) {
        this._frames = value;
        this.index = 0;
        this.counter = 0;
        if (value.length > 1 && !_initUpdateables.includes(this)) {
            _initUpdateables.push(this);
        }
        else if (value.length == 1 && _initUpdateables.includes(this)) {
            _initUpdateables.splice(_initUpdateables.indexOf(this), 1);
        }
    }
    initUpdate() {
        if (this.counter == (this.updatesPerFrame - 1)) {
            this.index++;
            if (this.index == this._frames.length) {
                if (this.loop) {
                    this.index = 0;
                }
                else {
                    _initUpdateables.splice(_initUpdateables.indexOf(this), 1);
                }
            }
        }
        this.counter = (this.counter + 1) % this.updatesPerFrame;
    }
    async draw() {
        await new Promise((resolve, reject) => {
            const draw = () => {
                const frameWidth = _images[this.path].width / this.columns;
                const frameHeight = _images[this.path].height / this.rows;
                this.width ??= frameWidth;
                this.height ??= frameHeight;
                const sx = frameWidth * (this._frames[this.index] % this.columns);
                const sy = frameHeight * Math.floor(this._frames[this.index] / this.columns);
                ctx.drawImage(_images[this.path], sx, sy, frameWidth, frameHeight, this.x, this.y, this.width, this.height);
                resolve();
            };
            if (_images[this.path] == null) {
                _images[this.path] = new Image();
                _images[this.path].src = this.path;
                _images[this.path].addEventListener("load", draw);
                _images[this.path].addEventListener("error", () => {
                    reject(new Error("'path' can not be loaded"));
                });
            }
            else if (_images[this.path].complete) {
                draw();
            }
            else {
                _images[this.path].addEventListener("load", draw);
            }
        });
    }
}
//
// Keyboard
//
export const keyboard = {
    get shiftLeft() { return keyboard["ShiftLeft"]; }, set shiftLeft(value) { keyboard["ShiftLeft"] = value; },
    get shiftRight() { return keyboard["ShiftRight"]; }, set shiftRight(value) { keyboard["ShiftRight"] = value; },
    get backspace() { return keyboard["Backspace"]; }, set backspace(value) { keyboard["Backspace"] = value; },
    get enter() { return keyboard["Enter"]; }, set enter(value) { keyboard["Enter"] = value; },
    get space() { return keyboard["Space"]; }, set space(value) { keyboard["Space"] = value; },
    get left() { return keyboard["ArrowLeft"]; }, set left(value) { keyboard["ArrowLeft"] = value; },
    get up() { return keyboard["ArrowUp"]; }, set up(value) { keyboard["ArrowUp"] = value; },
    get right() { return keyboard["ArrowRight"]; }, set right(value) { keyboard["ArrowRight"] = value; },
    get down() { return keyboard["ArrowDown"]; }, set down(value) { keyboard["ArrowDown"] = value; },
    get digit0() { return keyboard["Digit0"]; }, set digit0(value) { keyboard["Digit0"] = value; },
    get digit1() { return keyboard["Digit1"]; }, set digit1(value) { keyboard["Digit1"] = value; },
    get digit2() { return keyboard["Digit2"]; }, set digit2(value) { keyboard["Digit2"] = value; },
    get digit3() { return keyboard["Digit3"]; }, set digit3(value) { keyboard["Digit3"] = value; },
    get digit4() { return keyboard["Digit4"]; }, set digit4(value) { keyboard["Digit4"] = value; },
    get digit5() { return keyboard["Digit5"]; }, set digit5(value) { keyboard["Digit5"] = value; },
    get digit6() { return keyboard["Digit6"]; }, set digit6(value) { keyboard["Digit6"] = value; },
    get digit7() { return keyboard["Digit7"]; }, set digit7(value) { keyboard["Digit7"] = value; },
    get digit8() { return keyboard["Digit8"]; }, set digit8(value) { keyboard["Digit8"] = value; },
    get digit9() { return keyboard["Digit9"]; }, set digit9(value) { keyboard["Digit9"] = value; },
    get a() { return keyboard["KeyA"]; }, set a(value) { keyboard["KeyA"] = value; },
    get b() { return keyboard["KeyB"]; }, set b(value) { keyboard["KeyB"] = value; },
    get c() { return keyboard["KeyC"]; }, set c(value) { keyboard["KeyC"] = value; },
    get d() { return keyboard["KeyD"]; }, set d(value) { keyboard["KeyD"] = value; },
    get e() { return keyboard["KeyE"]; }, set e(value) { keyboard["KeyE"] = value; },
    get f() { return keyboard["KeyF"]; }, set f(value) { keyboard["KeyF"] = value; },
    get g() { return keyboard["KeyG"]; }, set g(value) { keyboard["KeyG"] = value; },
    get h() { return keyboard["KeyH"]; }, set h(value) { keyboard["KeyH"] = value; },
    get i() { return keyboard["KeyI"]; }, set i(value) { keyboard["KeyI"] = value; },
    get j() { return keyboard["KeyJ"]; }, set j(value) { keyboard["KeyJ"] = value; },
    get k() { return keyboard["KeyK"]; }, set k(value) { keyboard["KeyK"] = value; },
    get l() { return keyboard["KeyL"]; }, set l(value) { keyboard["KeyL"] = value; },
    get m() { return keyboard["KeyM"]; }, set m(value) { keyboard["KeyM"] = value; },
    get n() { return keyboard["KeyN"]; }, set n(value) { keyboard["KeyN"] = value; },
    get o() { return keyboard["KeyO"]; }, set o(value) { keyboard["KeyO"] = value; },
    get p() { return keyboard["KeyP"]; }, set p(value) { keyboard["KeyP"] = value; },
    get q() { return keyboard["KeyQ"]; }, set q(value) { keyboard["KeyQ"] = value; },
    get r() { return keyboard["KeyR"]; }, set r(value) { keyboard["KeyR"] = value; },
    get s() { return keyboard["KeyS"]; }, set s(value) { keyboard["KeyS"] = value; },
    get t() { return keyboard["KeyT"]; }, set t(value) { keyboard["KeyT"] = value; },
    get u() { return keyboard["KeyU"]; }, set u(value) { keyboard["KeyU"] = value; },
    get v() { return keyboard["KeyV"]; }, set v(value) { keyboard["KeyV"] = value; },
    get w() { return keyboard["KeyW"]; }, set w(value) { keyboard["KeyW"] = value; },
    get x() { return keyboard["KeyX"]; }, set x(value) { keyboard["KeyX"] = value; },
    get y() { return keyboard["KeyY"]; }, set y(value) { keyboard["KeyY"] = value; },
    get z() { return keyboard["KeyZ"]; }, set z(value) { keyboard["KeyZ"] = value; },
    poll: () => {
        return _key;
    }
};
window.addEventListener("blur", () => {
    keyboard["AltLeft"] = false;
});
//
// Mouse
//
export const mouse = {
    x: null,
    y: null,
    over: null,
    get left() { return mouse[0]; }, set left(value) { mouse[0] = value; },
    get middle() { return mouse[1]; }, set middle(value) { mouse[1] = value; },
    get right() { return mouse[2]; }, set right(value) { mouse[2] = value; }
};
//
// Touchscreen
//
let _touched = null;
export const touchscreen = {
    x: null,
    y: null,
    touches: [],
    get touched() { return _touched; }, set touched(value) { _touched = value; }
};
//
// Turtle
//
export class Turtle {
    x;
    y;
    turtleContainer = addSVG("svg", { width: 20, height: 20 });
    turtle;
    pen = true;
    visible = true;
    path = [];
    heading = 0;
    delay = 100;
    penSize = 1;
    constructor(x = W / 2, y = H / 2) {
        this.x = x;
        this.y = y;
        this.turtleContainer.style.position = "absolute";
        this.turtle = addSVG("polygon", { points: "0,0 10,10, 0,20", fill: _color }, this.turtleContainer);
        this.right(0);
        this.forward(0);
    }
    get penColor() {
        return this.turtle.getAttribute("fill");
    }
    set penColor(value) {
        this.turtle.setAttribute("fill", value);
    }
    async forward(length) {
        await sleep(this.delay);
        ctx.beginPath();
        ctx.moveTo(this.x, this.y);
        this.x += Math.cos(radians(this.heading)) * length;
        this.y += Math.sin(radians(this.heading)) * length;
        this.path.push([this.x, this.y]);
        if (this.pen) {
            ctx.lineTo(this.x, this.y);
            ctx.strokeStyle = this.penColor;
            ctx.lineWidth = this.penSize;
            ctx.stroke();
        }
        else {
            ctx.moveTo(this.x, this.y);
        }
        if (this.visible) {
            this.turtleContainer.style.left = (_canvas.offsetLeft + (this.x - 10)) / _scaleX + "px";
            this.turtleContainer.style.top = (_canvas.offsetTop + (this.y - 10)) / _scaleY + "px";
        }
    }
    async backward(length) {
        await this.forward(-length);
    }
    async right(degAngle = 90) {
        await sleep(this.delay);
        this.heading += degAngle;
        let [x1, y1] = fromPolar(10, this.heading + 150, 10, 10);
        let [x2, y2] = fromPolar(6, this.heading + 180, 10, 10);
        let [x3, y3] = fromPolar(10, this.heading - 150, 10, 10);
        this.turtle.setAttribute("points", `10,10 ${x1},${y1} ${x2},${y2} ${x3},${y3}`);
    }
    async left(degAngle = 90) {
        await this.right(-degAngle);
    }
    penUp() {
        this.pen = false;
    }
    penDown() {
        this.pen = true;
    }
    hide() {
        this.visible = false;
        this.turtleContainer.style.display = "none";
    }
    show() {
        this.visible = true;
        this.turtleContainer.style.display = "block";
    }
}
//
// Grid
//
const _charCanvas = document.createElement("canvas");
const _charCtx = _charCanvas.getContext("2d");
_charCtx.font = "124px monospace";
_charCanvas.width = _charCtx.measureText("X").width;
_charCanvas.height = 124;
_charCtx.font = "124px monospace";
export class Cell {
    _grid;
    row;
    column;
    x;
    y;
    width;
    height;
    tag = {};
    _style;
    _char;
    _charColor = _color;
    _charImage;
    _image;
    _custom;
    setCharImage() {
        _charCtx.clearRect(0, 0, _charCanvas.width, _charCanvas.height);
        _charCtx.fillStyle = this._charColor;
        _charCtx.fillText(this._char, 0, 124 * 0.8);
        this._charImage = _charCanvas.toDataURL("image/png");
    }
    constructor(_grid, row, column, x, y, width, height) {
        this._grid = _grid;
        this.row = row;
        this.column = column;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    get grid() {
        return this._grid;
    }
    get style() {
        return this._style;
    }
    set style(value) {
        this._style = value;
        this.draw();
    }
    get char() {
        return this._char;
    }
    set char(value) {
        this._char = value[0];
        this.setCharImage();
        this.draw();
    }
    get charColor() {
        return this._charColor;
    }
    set charColor(value) {
        this._charColor = value;
        this.setCharImage();
        this.draw();
    }
    get image() {
        return this._image;
    }
    set image(value) {
        this._image = value;
        this.draw();
    }
    get custom() {
        return this._custom;
    }
    set custom(value) {
        this._custom = value;
        this.draw();
    }
    async draw() {
        clear(this.x, this.y, this.width, this.height);
        if (this._style) {
            fill(this._style, this.x, this.y, this.width, this.height);
        }
        if (this._image) {
            await image(this._image, this.x, this.y, this.width, this.height);
        }
        if (this._char) {
            image(this._charImage, this.x, this.y, this.width, this.height);
        }
        if (this._custom) {
            this._custom(this);
        }
    }
}
class _Grid {
    cellWidth;
    cellHeight;
    constructor(rows, columns, x, y, width, height, gap) {
        this.cellWidth = (width - (columns + 1) * gap) / columns;
        this.cellHeight = (height - (rows + 1) * gap) / rows;
        for (let i = 0; i < rows; i++) {
            this[i] = [];
            for (let j = 0; j < columns; j++) {
                this[i][j] = new Cell(this, i, j, x + j * (this.cellWidth + gap) + gap, y + i * (this.cellHeight + gap) + gap, this.cellWidth, this.cellHeight);
            }
        }
    }
}
export class Grid extends _Grid {
    rows;
    columns;
    x;
    y;
    width;
    height;
    style;
    lineWidth;
    activatable = true;
    _activeCell = null;
    constructor(rows, columns, x = 0, y = 0, width = W - 2 * x, height = H - 2 * y, style = _color, lineWidth = 1) {
        super(rows, columns, x, y, width, height, lineWidth);
        this.rows = rows;
        this.columns = columns;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.style = style;
        this.lineWidth = lineWidth;
        this.draw();
    }
    get activated() {
        if (mouse[0] || _touched) {
            if (this.activatable) {
                let x = touchscreen.x;
                let y = touchscreen.y;
                if (mouse[0]) {
                    x = mouse.x;
                    y = mouse.y;
                }
                this._activeCell = this.getCell(x, y);
                this.activatable = false;
                return Boolean(this._activeCell);
            }
            else {
                return false;
            }
        }
        this.activatable = true;
        return false;
    }
    get activeCell() {
        return this._activeCell;
    }
    getCell(x, y) {
        let row;
        let column;
        if ((x - this.x - this.lineWidth + this.cellWidth + this.lineWidth) % (this.cellWidth + this.lineWidth) < this.cellWidth) {
            column = Math.floor((x - this.x) / (this.cellWidth + this.lineWidth));
            if (column < 0 || column >= this.columns) {
                return null;
            }
        }
        else {
            return null;
        }
        if ((y - this.y - this.lineWidth + this.cellHeight + this.lineWidth) % (this.cellHeight + this.lineWidth) < this.cellHeight) {
            row = Math.floor((y - this.y) / (this.cellHeight + this.lineWidth));
            if (row < 0 || row >= this.rows) {
                return null;
            }
        }
        else {
            return null;
        }
        return this[row][column];
    }
    draw() {
        if (this.style) {
            fill(this.style, this.x, this.y, this.width, this.height);
        }
        for (let i = 0; i < this.rows; i++) {
            for (let j = 0; j < this.columns; j++) {
                this[i][j].draw();
            }
        }
    }
}
//
// Helper functions
//
export function ord(char) {
    return char.charCodeAt(0);
}
export function chr(charCode) {
    return String.fromCharCode(charCode);
}
export function randomInt(m, n) {
    return n != null ? Math.trunc(m) + Math.floor(Math.random() * (n - m + 1)) : Math.floor(Math.random() * m);
}
export function randomItem(...items) {
    return items[Math.floor(Math.random() * items.length)];
}
export function radians(degAngle) {
    return degAngle * Math.PI / 180;
}
export function degrees(radAngle) {
    return radAngle * 180 / Math.PI;
}
export function fromPolar(radius, degAngle, x0 = 0, y0 = 0) {
    const a = radians(degAngle);
    return [x0 + Math.cos(a) * radius, y0 + Math.sin(a) * radius];
}
export function rgba(red, green, blue, alpha = 1) {
    return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
}
export function hsla(hue, saturation, light, alpha = 1) {
    return `hsla(${hue}, ${saturation}%, ${light}%, ${alpha})`;
}
export function getPixel(x, y) {
    const data = ctx.getImageData(x, y, 1, 1).data;
    return { red: data[0], green: data[1], blue: data[2], alpha: data[3] };
}
export function distance(x1, y1, x2, y2) {
    return Math.hypot(x2 - x1, y2 - y1);
}
export async function sleep(msDuration) {
    await new Promise(resolve => setTimeout(() => resolve(), msDuration)); // todo, reject?
}
export function array(length, value) {
    if (typeof value == "function") {
        let a = [];
        for (let i = 0; i < length; i++) {
            a[i] = value.call(null, i);
        }
        return a;
    }
    return Array(length).fill(value);
}
export function array2D(rows, columns, value) {
    if (typeof value == "function") {
        let m = array2D(rows, columns);
        for (let i = 0; i < rows; i++) {
            for (let j = 0; j < columns; j++) {
                m[i][j] = value.call(null, i, j);
            }
        }
        return m;
    }
    return Array(rows).fill(null).map(() => Array(columns).fill(value));
}
export function range(a, b, c = 1) {
    let r = [];
    if (b == null) {
        [a, b] = [0, a];
    }
    if (c > 0) {
        for (let i = a; i < b; i += c) {
            r.push(i);
        }
    }
    else if (c < 0) {
        for (let i = a; i > b; i += c) {
            r.push(i);
        }
    }
    else {
        throw new RangeError("'by' must not be zero");
    }
    return r;
}
export function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = randomInt(i + 1);
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}
export function add(tagName, arg1, arg2) {
    let elt;
    if ((typeof arg1 == "string" && _lbltags.includes(tagName.split(":")[0])) ||
        (typeof arg1 == "object" && arg1 != null && Object.keys(arg1).includes("label"))) {
        let labelElt = add("label", arg2);
        if (typeof arg1 == "object" && arg1["inline"]) {
            labelElt.style.display = "inline-block";
        }
        else {
            labelElt.style.display = "block";
            labelElt.style.margin = "1em 0";
        }
        if (["input:checkbox", "input:radio"].includes(tagName)) {
            if (typeof arg1 == "string") {
                arg1 = { label: arg1, placement: "right" };
            }
            else if (!arg1["placement"]) {
                arg1["placement"] = "right";
            }
        }
        let label = typeof arg1 == "string" ? arg1 : arg1["label"];
        let placement = typeof arg1 == "string" ? "top" : arg1["placement"] ?? "top";
        let spanElt;
        if (placement == "top" || placement == "left") {
            spanElt = add("span", label, labelElt);
            if (placement == "top") {
                add("br", labelElt);
            }
            elt = add(tagName, labelElt);
        }
        else {
            elt = add(tagName, labelElt);
            if (placement == "bottom") {
                add("br", labelElt);
            }
            spanElt = add("span", label, labelElt);
        }
        if (placement == "left" || placement == "right") {
            spanElt.style.verticalAlign = "top";
        }
        return elt;
    }
    else if (typeof arg1 == "string") {
        elt = document.createElement(tagName);
        if (tagName == "fieldset") {
            add("legend", arg1, elt);
        }
        else {
            elt["textContent"] = arg1;
        }
    }
    else {
        if (arg1) {
            arg2 = arg1;
        }
        if (tagName.startsWith("input:")) {
            elt = document.createElement("input");
            elt["type"] = tagName.substr(6);
        }
        else if (tagName.startsWith("select:")) {
            elt = document.createElement("select");
            if (tagName.substr(7) == "listbox") {
                elt["size"] = 4;
            }
        }
        else {
            elt = document.createElement(tagName);
        }
    }
    let parent = _parent ?? document.body;
    let before = null;
    let spacing = true;
    if (arg2) {
        if (arg2 instanceof HTMLElement) {
            parent = arg2;
        }
        else {
            if (arg2["parent"] != null)
                parent = arg2["parent"];
            if (arg2["before"] != null)
                before = arg2["before"];
            if (arg2["spacing"] != null)
                spacing = arg2["spacing"];
        }
    }
    if (tagName == "input:radio") {
        elt["name"] = parent instanceof HTMLFieldSetElement ?
            parent.querySelector("legend")?.textContent :
            parent.parentElement instanceof HTMLFieldSetElement ?
                parent.parentElement.querySelector("legend")?.textContent :
                null;
    }
    if (spacing) {
        before = parent.insertBefore(document.createTextNode("\n"), before);
    }
    let ph0 = parent == _parent ? parseInt(getComputedStyle(_parent).height) : 0;
    parent.insertBefore(elt, before);
    let ph1 = parent == _parent ? parseInt(getComputedStyle(_parent).height) : 0;
    if (ph0 != ph1) {
        resetCanvas();
    }
    return elt;
}
export function setLabel(labeledElement, text) {
    if (labeledElement.parentElement instanceof HTMLLabelElement) {
        const spanElt = labeledElement.parentElement.querySelector("span");
        if (spanElt) {
            spanElt.textContent = text;
            return;
        }
        else {
            const fc = labeledElement.parentElement.firstChild;
            const lc = labeledElement.parentElement.lastChild;
            if (fc != labeledElement && fc.textContent.trim() != "") {
                fc.textContent = text + " ";
            }
            else if (lc != labeledElement && lc.textContent.trim() != "") {
                lc.textContent = " " + text;
            }
            else {
                labeledElement.parentElement.insertBefore(document.createTextNode(text + " "), labeledElement);
                labeledElement.parentElement.normalize();
            }
            return;
        }
    }
    else if (labeledElement.id) {
        const labelElt = document.querySelector(`label[for=${labeledElement.id}`);
        if (labelElt) {
            labelElt.textContent = text;
            return;
        }
    }
    throw new Error("'labeledElement' is not labeled");
}
export function getLabel(labeledElement) {
    if (labeledElement.parentElement instanceof HTMLLabelElement) {
        const spanElt = labeledElement.parentElement.querySelector("span");
        if (spanElt) {
            return spanElt.textContent;
        }
        else {
            const fc = labeledElement.parentElement.firstChild;
            const lc = labeledElement.parentElement.lastChild;
            if (fc != labeledElement && fc.textContent.trim() != "") {
                return fc.textContent.trim();
            }
            else if (lc != labeledElement && lc.textContent.trim() != "") {
                return lc.textContent.trim();
            }
            else {
                return "";
            }
        }
    }
    else if (labeledElement.id) {
        const labelElt = document.querySelector(`label[for=${labeledElement.id}`);
        if (labelElt) {
            return labelElt.textContent;
        }
    }
    throw new Error("'labeledElement' is not labeled");
}
export function addSVG(tagName, arg1, arg2) {
    let elt = document.createElementNS("http://www.w3.org/2000/svg", tagName);
    if (arg1 === undefined) {
        document.body.appendChild(elt);
    }
    else if (arg1 instanceof HTMLElement || arg1 instanceof SVGSVGElement) {
        arg1.appendChild(elt);
    }
    else {
        for (const key in arg1) {
            elt.setAttribute(key, arg1[key]);
        }
        (arg2 ?? document.body).appendChild(elt);
    }
    return elt;
}
if (!_canvas) {
    document.documentElement.style.height = "100%";
    document.documentElement.style.display = "flex";
    document.documentElement.style.flexFlow = "column";
    document.body.style.height = "100%";
    document.body.style.display = "flex";
    document.body.style.flexFlow = "column";
    if (!_parent)
        add("balder-parent", document.body);
    add("balder-canvas", document.body);
}
//# sourceMappingURL=balder.js.map