import { circle, W, H } from "./balder.js"

circle(W / 2, H / 3, 50, "red")
